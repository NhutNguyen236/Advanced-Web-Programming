1. Gõ "npm instal" để cài các modules cần thiết
2. Gõ "npm start" để chạy web site trên cổng 9090

(Hãy nâng cấp nodejs lên phiên bản 14+ và cài đặt mongodb trước)